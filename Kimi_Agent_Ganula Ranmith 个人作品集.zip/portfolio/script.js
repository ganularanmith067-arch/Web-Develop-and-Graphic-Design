/* ==========================================
   Portfolio Website - JavaScript
   Ganula Ranmith - Graphic Designer & Web Developer
   ========================================== */

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    
    /* ==========================================
       Loading Screen
       ========================================== */
    const loadingScreen = document.getElementById('loadingScreen');
    
    setTimeout(() => {
        loadingScreen.classList.add('hidden');
    }, 2500);
    
    /* ==========================================
       Typing Effect
       ========================================== */
    const typingText = document.getElementById('typingText');
    const roles = [
        'Graphic Designer',
        'Web Developer',
        'UI/UX Designer',
        'Creative Thinker'
    ];
    let roleIndex = 0;
    let charIndex = 0;
    let isDeleting = false;
    let typingSpeed = 100;
    
    function typeEffect() {
        const currentRole = roles[roleIndex];
        
        if (isDeleting) {
            typingText.textContent = currentRole.substring(0, charIndex - 1);
            charIndex--;
            typingSpeed = 50;
        } else {
            typingText.textContent = currentRole.substring(0, charIndex + 1);
            charIndex++;
            typingSpeed = 100;
        }
        
        if (!isDeleting && charIndex === currentRole.length) {
            isDeleting = true;
            typingSpeed = 2000; // Pause at end
        } else if (isDeleting && charIndex === 0) {
            isDeleting = false;
            roleIndex = (roleIndex + 1) % roles.length;
            typingSpeed = 500; // Pause before typing
        }
        
        setTimeout(typeEffect, typingSpeed);
    }
    
    // Start typing effect after loading
    setTimeout(typeEffect, 3000);
    
    /* ==========================================
       Navigation
       ========================================== */
    const navbar = document.getElementById('navbar');
    const navToggle = document.getElementById('navToggle');
    const navMenu = document.getElementById('navMenu');
    const navLinks = document.querySelectorAll('.nav-link');
    
    // Sticky navbar on scroll
    window.addEventListener('scroll', () => {
        if (window.scrollY > 100) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });
    
    // Mobile menu toggle
    navToggle.addEventListener('click', () => {
        navToggle.classList.toggle('active');
        navMenu.classList.toggle('active');
    });
    
    // Close mobile menu when link is clicked
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            navToggle.classList.remove('active');
            navMenu.classList.remove('active');
        });
    });
    
    // Active nav link on scroll
    const sections = document.querySelectorAll('section');
    
    window.addEventListener('scroll', () => {
        let current = '';
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.clientHeight;
            
            if (scrollY >= sectionTop - 200) {
                current = section.getAttribute('id');
            }
        });
        
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${current}`) {
                link.classList.add('active');
            }
        });
    });
    
    /* ==========================================
       Scroll Reveal Animation
       ========================================== */
    const revealElements = document.querySelectorAll(
        '.section-header, .about-image-wrapper, .about-info, .skill-item, ' +
        '.portfolio-item, .service-card, .contact-info, .contact-form-wrapper, .contact-item'
    );
    
    const revealObserver = new IntersectionObserver((entries) => {
        entries.forEach((entry, index) => {
            if (entry.isIntersecting) {
                // Add stagger delay for elements within the same container
                const staggerDelay = entry.target.dataset.stagger 
                    ? parseInt(entry.target.dataset.stagger) * 100 
                    : 0;
                
                setTimeout(() => {
                    entry.target.classList.add('active');
                }, staggerDelay);
                
                revealObserver.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    });
    
    revealElements.forEach(el => {
        el.classList.add('reveal');
        revealObserver.observe(el);
    });
    
    /* ==========================================
       Skills Progress Animation
       ========================================== */
    const skillBars = document.querySelectorAll('.skill-progress');
    
    const skillsObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const progressBar = entry.target;
                const width = progressBar.dataset.width;
                
                setTimeout(() => {
                    progressBar.style.width = width + '%';
                }, 200);
                
                skillsObserver.unobserve(progressBar);
            }
        });
    }, {
        threshold: 0.5
    });
    
    skillBars.forEach(bar => {
        skillsObserver.observe(bar);
    });
    
    /* ==========================================
       Portfolio Filter
       ========================================== */
    const filterBtns = document.querySelectorAll('.filter-btn');
    const portfolioItems = document.querySelectorAll('.portfolio-item');
    
    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            // Remove active class from all buttons
            filterBtns.forEach(b => b.classList.remove('active'));
            // Add active class to clicked button
            btn.classList.add('active');
            
            const filter = btn.dataset.filter;
            
            portfolioItems.forEach(item => {
                const category = item.dataset.category;
                
                if (filter === 'all' || category === filter) {
                    item.classList.remove('hidden');
                    setTimeout(() => {
                        item.style.opacity = '1';
                        item.style.transform = 'scale(1)';
                    }, 50);
                } else {
                    item.style.opacity = '0';
                    item.style.transform = 'scale(0.8)';
                    setTimeout(() => {
                        item.classList.add('hidden');
                    }, 300);
                }
            });
        });
    });
    
    /* ==========================================
       Portfolio Modal
       ========================================== */
    const modal = document.getElementById('portfolioModal');
    const modalClose = document.getElementById('modalClose');
    const modalImage = document.getElementById('modalImage');
    const modalTitle = document.getElementById('modalTitle');
    const modalCategory = document.getElementById('modalCategory');
    const modalDescription = document.getElementById('modalDescription');
    const portfolioViews = document.querySelectorAll('.portfolio-view');
    
    // Project data
    const projects = {
        1: {
            title: 'Brand Identity Design',
            category: 'Graphic Design',
            image: 'images/project1.jpg',
            description: 'A comprehensive brand identity project for Aqua Systems, featuring a modern logo design, business cards, and letterhead. The design incorporates geometric shapes and a refreshing cyan color palette that reflects the company\'s innovative approach to water solutions.'
        },
        2: {
            title: 'E-Commerce Platform',
            category: 'Web Development',
            image: 'images/project2.jpg',
            description: 'A luxury fashion e-commerce platform built with modern web technologies. Features include a responsive design, intuitive navigation, product filtering, and a seamless checkout experience. The dark theme with cyan accents creates an elegant shopping atmosphere.'
        },
        3: {
            title: 'Fitness App UI',
            category: 'UI/UX Design',
            image: 'images/project3.jpg',
            description: 'A modern fitness tracking mobile application with a dark mode interface. The design features glassmorphism elements, intuitive data visualization, and smooth animations. Users can track steps, heart rate, calories, and workout progress with ease.'
        },
        4: {
            title: 'Creative Poster Design',
            category: 'Graphic Design',
            image: 'images/project4.jpg',
            description: 'An abstract geometric poster design with bold typography. The composition features dynamic shapes, intersecting lines, and a vibrant cyan-to-green gradient that creates visual energy and captures attention instantly.'
        },
        5: {
            title: 'Analytics Dashboard',
            category: 'Web Development',
            image: 'images/project5.jpg',
            description: 'A comprehensive analytics dashboard for business intelligence. Features real-time data visualization, interactive charts, and key performance indicators. The dark theme reduces eye strain while the cyan accents highlight important metrics.'
        },
        6: {
            title: 'Logo Collection',
            category: 'Graphic Design',
            image: 'images/project6.jpg',
            description: 'A curated collection of minimalist logo designs for various brands. Each logo is crafted with careful attention to symbolism, scalability, and brand representation. The collection showcases versatility across different industries and design styles.'
        }
    };
    
    portfolioViews.forEach(btn => {
        btn.addEventListener('click', () => {
            const projectId = btn.dataset.project;
            const project = projects[projectId];
            
            if (project) {
                modalImage.src = project.image;
                modalImage.alt = project.title;
                modalTitle.textContent = project.title;
                modalCategory.textContent = project.category;
                modalDescription.textContent = project.description;
                
                modal.classList.add('active');
                document.body.style.overflow = 'hidden';
            }
        });
    });
    
    // Close modal
    modalClose.addEventListener('click', closeModal);
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            closeModal();
        }
    });
    
    function closeModal() {
        modal.classList.remove('active');
        document.body.style.overflow = '';
    }
    
    // Close modal on Escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && modal.classList.contains('active')) {
            closeModal();
        }
    });
    
    /* ==========================================
       Contact Form Validation
       ========================================== */
    const contactForm = document.getElementById('contactForm');
    const nameInput = document.getElementById('name');
    const emailInput = document.getElementById('email');
    const messageInput = document.getElementById('message');
    const formSuccess = document.getElementById('formSuccess');
    
    // Validation patterns
    const patterns = {
        name: /^[a-zA-Z\s]{2,50}$/,
        email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
        message: /^[\s\S]{10,500}$/
    };
    
    // Error messages
    const errorMessages = {
        name: 'Please enter a valid name (2-50 characters)',
        email: 'Please enter a valid email address',
        message: 'Message must be between 10-500 characters'
    };
    
    function validateField(input, pattern, errorId) {
        const value = input.value.trim();
        const errorElement = document.getElementById(errorId);
        const isValid = pattern.test(value);
        
        if (!isValid && value !== '') {
            errorElement.textContent = errorMessages[input.name];
            errorElement.classList.add('show');
            input.style.borderColor = '#ff4757';
        } else {
            errorElement.classList.remove('show');
            input.style.borderColor = isValid ? 'var(--primary)' : 'rgba(255, 255, 255, 0.1)';
        }
        
        return isValid;
    }
    
    // Real-time validation
    nameInput.addEventListener('blur', () => {
        validateField(nameInput, patterns.name, 'nameError');
    });
    
    emailInput.addEventListener('blur', () => {
        validateField(emailInput, patterns.email, 'emailError');
    });
    
    messageInput.addEventListener('blur', () => {
        validateField(messageInput, patterns.message, 'messageError');
    });
    
    // Clear error on focus
    [nameInput, emailInput, messageInput].forEach(input => {
        input.addEventListener('focus', () => {
            const errorId = input.id + 'Error';
            document.getElementById(errorId).classList.remove('show');
            input.style.borderColor = 'var(--primary)';
        });
    });
    
    // Form submission
    contactForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const isNameValid = validateField(nameInput, patterns.name, 'nameError');
        const isEmailValid = validateField(emailInput, patterns.email, 'emailError');
        const isMessageValid = validateField(messageInput, patterns.message, 'messageError');
        
        if (isNameValid && isEmailValid && isMessageValid) {
            // Simulate form submission
            const submitBtn = contactForm.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            
            submitBtn.innerHTML = '<span>Sending...</span><i class="fas fa-spinner fa-spin"></i>';
            submitBtn.disabled = true;
            
            setTimeout(() => {
                // Show success message
                formSuccess.classList.add('show');
                
                // Reset form
                contactForm.reset();
                
                // Reset button
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
                
                // Hide success message after 5 seconds
                setTimeout(() => {
                    formSuccess.classList.remove('show');
                }, 5000);
            }, 2000);
        }
    });
    
    /* ==========================================
       Back to Top Button
       ========================================== */
    const backToTop = document.getElementById('backToTop');
    
    window.addEventListener('scroll', () => {
        if (window.scrollY > 500) {
            backToTop.classList.add('visible');
        } else {
            backToTop.classList.remove('visible');
        }
    });
    
    backToTop.addEventListener('click', () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
    
    /* ==========================================
       Smooth Scroll for Anchor Links
       ========================================== */
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                const offsetTop = targetElement.offsetTop - 80; // Account for navbar
                
                window.scrollTo({
                    top: offsetTop,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    /* ==========================================
       Parallax Effect for Hero Orbs
       ========================================== */
    const orbs = document.querySelectorAll('.gradient-orb');
    
    window.addEventListener('mousemove', (e) => {
        const mouseX = e.clientX / window.innerWidth;
        const mouseY = e.clientY / window.innerHeight;
        
        orbs.forEach((orb, index) => {
            const speed = (index + 1) * 20;
            const x = (mouseX - 0.5) * speed;
            const y = (mouseY - 0.5) * speed;
            
            orb.style.transform = `translate(${x}px, ${y}px)`;
        });
    });
    
    /* ==========================================
       Counter Animation for Experience Badge
       ========================================== */
    const expNumber = document.querySelector('.exp-number');
    
    const counterObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                animateCounter(entry.target, 0, 5, 2000);
                counterObserver.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.5
    });
    
    if (expNumber) {
        counterObserver.observe(expNumber);
    }
    
    function animateCounter(element, start, end, duration) {
        let startTime = null;
        
        function step(timestamp) {
            if (!startTime) startTime = timestamp;
            const progress = Math.min((timestamp - startTime) / duration, 1);
            const value = Math.floor(progress * (end - start) + start);
            element.textContent = value + '+';
            
            if (progress < 1) {
                window.requestAnimationFrame(step);
            }
        }
        
        window.requestAnimationFrame(step);
    }
    
    /* ==========================================
       Service Card Hover Effect Enhancement
       ========================================== */
    const serviceCards = document.querySelectorAll('.service-card');
    
    serviceCards.forEach(card => {
        card.addEventListener('mouseenter', () => {
            serviceCards.forEach(c => {
                if (c !== card) {
                    c.style.opacity = '0.6';
                    c.style.transform = 'scale(0.98)';
                }
            });
        });
        
        card.addEventListener('mouseleave', () => {
            serviceCards.forEach(c => {
                c.style.opacity = '1';
                c.style.transform = '';
            });
        });
    });
    
    /* ==========================================
       Preload Images
       ========================================== */
    const imagesToPreload = [
        'images/profile.jpg',
        'images/project1.jpg',
        'images/project2.jpg',
        'images/project3.jpg',
        'images/project4.jpg',
        'images/project5.jpg',
        'images/project6.jpg'
    ];
    
    imagesToPreload.forEach(src => {
        const img = new Image();
        img.src = src;
    });
    
    /* ==========================================
       Console Welcome Message
       ========================================== */
    console.log('%c Welcome to Ganula Ranmith\'s Portfolio! ', 
        'background: linear-gradient(135deg, #00f5ff, #00ff88); color: #0a0a0a; font-size: 20px; font-weight: bold; padding: 10px 20px; border-radius: 10px;'
    );
    console.log('%c Looking for a Graphic Designer or Web Developer? Let\'s connect! ', 
        'color: #00f5ff; font-size: 14px;'
    );
    
});

/* ==========================================
   Utility Functions
   ========================================== */

// Debounce function for performance
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Throttle function for scroll events
function throttle(func, limit) {
    let inThrottle;
    return function(...args) {
        if (!inThrottle) {
            func.apply(this, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}
